<?php

include_once 'config.php';

$db = new mysqli(HOST, USER, PASSWORD, DATABASE);

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'GET'){
    
    $results = dir_sekolah_listing($db);
    
    if ($results)
    {
        echo json_encode($results);
        exit;
    }
    else
    {
        echo json_encode(array('error' => 'Tiada rekod.'));
        exit;    
    }
}
else
{
   echo json_encode(array('error' => 'Invalid action.'));
   exit; 
}

function dir_sekolah_listing($db){
    
    $outArr = false;
    
    $stmt1 = $db->prepare("SELECT * from sekolah ORDER BY id ASC");
    $stmt1->execute();
    $stmt1->store_result();
    $stmt1->bind_result($id, $name, $addr, $ppd, $status, $notel, $nofax, $sesi, $jns_bantuan, $jns_murid, $bhs_pghntr, $jns_asrama);
    while ($stmt1->fetch()) {
        $outArr[] = ['id' => $id, 'nama' => $name, 'addr' => $addr, 'ppd' => $ppd, 'status' => $status, 'notel' => $notel, 'nofax' => $nofax, 'sesi' => $sesi, 'jns_bantuan' => $jns_bantuan, 'jns_murid' => $jns_murid, 'bhs_pghntr' => $bhs_pghntr, 'jns_asrama' => $jns_asrama];
    }
    $stmt1->close();
    
    return $outArr;    
}