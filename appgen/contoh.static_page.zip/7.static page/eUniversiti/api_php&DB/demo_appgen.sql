-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 13, 2015 at 05:22 PM
-- Server version: 5.5.44
-- PHP Version: 5.4.42

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `demo_appgen`
--

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE IF NOT EXISTS `members` (
  `id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `nric` varchar(12) NOT NULL,
  `username` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` char(128) NOT NULL,
  `password_confirmation` char(128) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`id`, `first_name`, `last_name`, `nric`, `username`, `email`, `password`, `password_confirmation`) VALUES
(2, 'Sharol', 'Affandi', '840512045379', 'sharol', 'test@dapat.com', 'e10adc3949ba59abbe56e057f20f883e', 'e10adc3949ba59abbe56e057f20f883e'),
(10, 'daniel', 'don', '150715141010', 'daniel don', 'don-daniel@gmail.com', '25d55ad283aa400af464c76d713c07ad', '25d55ad283aa400af464c76d713c07ad'),
(11, 'test', 'test', '123456789012', 'test', 'test@example.com', '25d55ad283aa400af464c76d713c07ad', '25d55ad283aa400af464c76d713c07ad'),
(12, 'aizan', 'awang', '123456789012', 'aizan', 'aizan@dapat.com', '25d55ad283aa400af464c76d713c07ad', '25d55ad283aa400af464c76d713c07ad'),
(24, 'dahlia', 'hassan', '860323565736', 'dahlia', 'dahlia@yahoo.com', '1ea30a340d5d6c35109987d43566fcdf', '1ea30a340d5d6c35109987d43566fcdf'),
(26, 'cempaka', 'jebat', '123456789012', 'cempaka', 'cempaka@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', '827ccb0eea8a706c4c34a16891f84e7b'),
(27, 'shieda', 'ishak', '123456789012', 'shahieda', 'shahieda@dapat.com', '25d55ad283aa400af464c76d713c07ad', '25d55ad283aa400af464c76d713c07ad'),
(28, 'marzuki', 'ahmad', '810291029029', 'marzuki', 'marzuki.a@moh.gov.my', '827ccb0eea8a706c4c34a16891f84e7b', '827ccb0eea8a706c4c34a16891f84e7b'),
(29, 'fara', 'liza', '222222222222', 'fara', 'faraliza@dapat.com', '25d55ad283aa400af464c76d713c07ad', '25d55ad283aa400af464c76d713c07ad'),
(30, 'test', 'test', '123456787654', 'test', 'test@yahoo.com', '25d55ad283aa400af464c76d713c07ad', '25d55ad283aa400af464c76d713c07ad'),
(31, 'haine', 'y', '800107065556', 'haine', 'haine@mampu.gov.my', '25d55ad283aa400af464c76d713c07ad', '25d55ad283aa400af464c76d713c07ad'),
(32, 'sawa', 'abu', '123', 'sawa', 'sawalrudin@mampu.gov.my', 'e10adc3949ba59abbe56e057f20f883e', 'e10adc3949ba59abbe56e057f20f883e'),
(33, 'gda', 'aga', 'aga', 'aga', 'aga', 'fea30f2213e57de1a3c985f0cad303b7', 'fea30f2213e57de1a3c985f0cad303b7'),
(34, 'sawa', 'a', '1234567890', 'sawalrudin', 'akusawal16@gmail.com', '202cb962ac59075b964b07152d234b70', '202cb962ac59075b964b07152d234b70'),
(35, 'mohd', 'asyraf', '123123', 'mohdasyraf', 'mohdasyraf@gmail.com', '5f4dcc3b5aa765d61d8327deb882cf99', '5f4dcc3b5aa765d61d8327deb882cf99'),
(36, 'WONG CHING CHING', 'WONG', '800112142343', 'cching', 'cching@mampu.gov.my', 'e10adc3949ba59abbe56e057f20f883e', 'e10adc3949ba59abbe56e057f20f883e'),
(37, 'aaaa', 'cccc', 'qqqq', 'qqq', 'anisah@mampu.gov.my', '25d55ad283aa400af464c76d713c07ad', '25d55ad283aa400af464c76d713c07ad'),
(38, 'Yusnida', 'Yusoff', '123456789012', 'Yusnida', 'missgetchoo@yahoo.com', '76a2173be6393254e72ffa4d6df1030a', '76a2173be6393254e72ffa4d6df1030a'),
(46, 'efzez', 'awang2', '850124115251', 'efzez', 'efzez@yahoo.com', '25d55ad283aa400af464c76d713c07ad', '25d55ad283aa400af464c76d713c07ad'),
(47, 'Mohd Iskandar', 'Bin Mohd Ali', '840426105347', 'iskandarali', 'miskandarmali@gmail.com', '25d55ad283aa400af464c76d713c07ad', '25d55ad283aa400af464c76d713c07ad'),
(48, 'halimatun', 'haron', '820117025126', 'halimatun', 'halimatunsaadiah.haron@gmail.com.my', 'bbb0ddff1b944b3cc68eaaeb7ac20099', 'bbb0ddff1b944b3cc68eaaeb7ac20099'),
(49, 'edy', 'ahmed', '888888118888', 'edy', 'suhaidee@jpn.gov.my', '25d55ad283aa400af464c76d713c07ad', '25d55ad283aa400af464c76d713c07ad'),
(50, 'Ahmad Shuami', 'Abdul Ghani', '790812115137', 'shuami', 'shuami@mampu.gov.my', 'b3b0ef1a8fd1e15b8246175edc116b9b', 'b3b0ef1a8fd1e15b8246175edc116b9b'),
(51, 'shah', 'asmuni', '77777777', 'shah', 'shah.asmuni@inform.gov.my', '8b11e9cc5e03ac85cc5ab2b9a6a3484a', '8b11e9cc5e03ac85cc5ab2b9a6a3484a'),
(52, 'Shzr', 'Ashary', '345678004321', 'Shzr', 'shazir@adk.gov.my', '823da4223e46ec671a10ea13d7823534', '823da4223e46ec671a10ea13d7823534'),
(53, 'safwan', 'saleh', '860606065887', 'safwan', 'safwan@hotmail.com', '827ccb0eea8a706c4c34a16891f84e7b', '827ccb0eea8a706c4c34a16891f84e7b'),
(54, 'farahdila', 'hairoman', '787911109099', 'Dila', 'farahdila@miti.gov.my', '25d55ad283aa400af464c76d713c07ad', '25d55ad283aa400af464c76d713c07ad'),
(55, 'Adam Muhammad Richard', 'Paulinus', '830403125127', 'Adam Muhammad Richard', 'adamrichard@mampu.gov.my', 'bcf887a5f0a48c3492333dfcb6428891', 'bcf887a5f0a48c3492333dfcb6428891'),
(56, 'halida', 'ibrahim', '000000-00-00', 'halida', 'halida@miti.gov.my', '25d55ad283aa400af464c76d713c07ad', '25d55ad283aa400af464c76d713c07ad'),
(57, 'safwansaleh', 'saleh', '870707075777', 'saf', 'safwan@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', '827ccb0eea8a706c4c34a16891f84e7b'),
(58, 'shah', 'asmuni', '11111', 'shah', 'shah.asmuni2@inform.gov.my', '5830d8a1b0cf1c12afa4e4ef4fdcbf66', '5830d8a1b0cf1c12afa4e4ef4fdcbf66'),
(59, 'nur', 'haron', '820117', 'halimatun', 'suka@gmail.com', 'eac1fa69e61e53389485c3bf1df56aef', 'eac1fa69e61e53389485c3bf1df56aef');

-- --------------------------------------------------------

--
-- Table structure for table `peperiksaan`
--

CREATE TABLE IF NOT EXISTS `peperiksaan` (
  `id` int(255) NOT NULL,
  `ic` bigint(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `peperiksaan`
--

INSERT INTO `peperiksaan` (`id`, `ic`, `name`, `status`) VALUES
(1, 123456112345, 'izan', 'lulus');

-- --------------------------------------------------------

--
-- Table structure for table `sekolah`
--

CREATE TABLE IF NOT EXISTS `sekolah` (
  `Id` int(2) DEFAULT NULL,
  `Nama Sekolah` varchar(36) DEFAULT NULL,
  `Alamat` varchar(66) DEFAULT NULL,
  `PPD` varchar(23) DEFAULT NULL,
  `Status` varchar(36) DEFAULT NULL,
  `No Telefon` bigint(11) DEFAULT NULL,
  `No Fax` bigint(11) DEFAULT NULL,
  `Sesi` varchar(15) DEFAULT NULL,
  `Jenis Bantuan` varchar(24) DEFAULT NULL,
  `Jenis Murid` varchar(20) DEFAULT NULL,
  `Bahasa Pengantar` varchar(19) DEFAULT NULL,
  `Jenis Asrama` varchar(21) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sekolah`
--

INSERT INTO `sekolah` (`Id`, `Nama Sekolah`, `Alamat`, `PPD`, `Status`, `No Telefon`, `No Fax`, `Sesi`, `Jenis Bantuan`, `Jenis Murid`, `Bahasa Pengantar`, `Jenis Asrama`) VALUES
(1, 'SEKOLAH MENENGAH SAINS BANTING', 'JALAN SULTAN SULEIMAN SHAH , JUGRA, BANTING 42700 SELANGOR', 'PPD KUALA LANGAT', 'Beroperasi', 60331201597, 60331201623, 'Pagi Sahaja', 'Sekolah Kerajaan', 'Lelaki dan Perempuan', 'Bahasa Melayu', 'Asrama Penuh'),
(2, 'SM SAINS HULU SELANGOR', 'HULU YAM BHARU, BATANG KALI, 44300 SELANGOR', 'PPD HULU SELANGOR', 'Beroperasi', 60360753838, 60360751416, 'Pagi Sahaja', 'Sekolah Kerajaan', 'Lelaki dan Perempuan', 'Bahasa Melayu', 'Asrama Penuh'),
(3, 'SM SAINS KUALA SELANGOR', 'JALAN STADIUM, KUALA SELANGOR, 45000 SELANGOR', 'PPD KUALA SELANGOR', 'Beroperasi', 60332891868, 60332896631, 'Pagi Sahaja', 'Sekolah Kerajaan', 'Lelaki dan Perempuan', 'Bahasa Melayu', 'Asrama Penuh'),
(4, 'SMK ABDUL JALIL', 'KM 22, JLN HULU LANGAT, HULU LANGAT, 43100 SELANGOR', 'PPD HULU LANGAT', 'Beroperasi', 60390211332, 60390214452, 'Pagi dan Petang', 'Sekolah Kerajaan', 'Lelaki dan Perempuan', 'Bahasa Melayu', 'Asrama Sekolah Harian'),
(5, 'SMK ALAM MEGAH', 'JLN. SG. BATU 27/72,SEKSYEN 27, SHAH ALAM, 40400 SELANGOR', 'PPD PETALING PERDANA', 'Beroperasi', 60351910709, 60351920442, 'Pagi Sahaja', 'Sekolah Kerajaan', 'Lelaki dan Perempuan', 'Bahasa Melayu', 'Tiada Asrama'),
(6, 'SMK BANDAR SUNWAY', 'JALAN PJS 7/15, PETALING JAYA, 46150 SELANGOR ', 'PPD PETALING PERDANA', 'Beroperasi', 60356328335, 60356325149, 'Pagi dan Petang', 'Sekolah Kerajaan', 'Lelaki dan Perempuan', 'ahasa Melayu', 'Tiada Asrama'),
(7, 'SMK BANDAR BARU SUNGAI LONG', 'JALAN SUNGAI LONG, BANDAR BARU SUNGAI LONG, KAJANG, 43000 SELANGOR', 'PPD HULU LANGAT', 'Beroperasi', 60390753549, 60390753784, 'Pagi dan Petang', 'Sekolah Kerajaan', 'Lelaki dan Perempuan', 'Bahasa Melayu', 'Tiada Asrama'),
(8, 'SMK BANDAR UTAMA', '1 PINTASAN BANDAR UTAMA, PETALING JAYA, 47800 SELANGOR', 'PPD PETALING UTAMA', 'Beroperasi', 60377252829, 60377263708, 'Pagi Sahaja', 'Sekolah Kerajaan', 'Lelaki dan Perempuan', 'Bahasa Melayu', 'Tiada Asrama'),
(9, 'SMK DATO HARUN', 'BATU 8, JALAN BERNAM, TANJONG KARANG, 45500 SELANGOR', 'PPD KUALA SELANGOR', 'Beroperasi', 60332698151, 60332692769, 'Pagi Sahaja', 'Sekolah Kerajaan', 'Lelaki dan Perempuan', 'Bahasa Melayu', 'Asrama Sekolah Harian'),
(10, 'SMK GOMBAK SETIA', 'JALAN SERI SETIA, GOMBAK, 53100 SELANGOR', 'PPD GOMBAK', 'Beroperasi', 60361896329, 60361851355, 'Pagi dan Petang', 'Sekolah Kerajaan', 'Lelaki dan Perempuan', 'Bahasa Melayu', 'Tiada Asrama'),
(11, 'SMK JENJAROM', 'KG JENJAROM, JENJAROM, 42600 SELANGOR', 'PPD KUALA LANGAT', 'Beroperasi', 60331913977, 60331913977, 'Pagi dan Petang', 'Sekolah Kerajaan', 'Lelaki dan Perempuan', 'Bahasa Melayu', 'Tiada Asrama'),
(12, 'SMK KELANA JAYA', 'JALAN BAHAGIA SS4, PETALING JAYA, 47301 SELANGOR', 'PPD PETALING UTAMA', 'Beroperasi', 60378035121, 60378035120, 'Pagi Sahaja', 'Sekolah Kerajaan', 'Lelaki dan Perempuan', 'Bahasa Melayu', 'Tiada Asrama'),
(13, 'SMK SEKSYEN 18', 'JLN KELAPA BALI 18/43, SHAH ALAM, 40200 SELANGOR', 'PPD PETALING PERDANA', 'Beroperasi', 60355421403, 60355491659, 'Pagi dan Petang', 'Sekolah Kerajaan', 'Lelaki dan Perempuan', 'Bahasa Melayu', 'Asrama Sekolah Harian'),
(14, 'SAM JERAM', 'JERAM, KUALA SELANGOR, 45800 SELANGOR', 'PPD KUALA SELANGOR', 'Beroperasi', 60332647396, 60332648499, 'Pagi Sahaja', 'Sekolah Bantuan Kerajaan', 'Lelaki dan Perempuan', 'B. Melayu + B. Arab', 'Asrama Sekolah Harian'),
(15, 'SAM HISAMUDDIN', 'JALAN TEPI SUNGAI, SUNGAI BERTIH, KLANG, 41100 SELANGOR', 'PPD KLANG', 'Beroperasi', 60333724120, 60333742673, 'Pagi Sahaja', 'Sekolah Bantuan Kerajaan', 'Lelaki dan Perempuan', 'B. Melayu + B. Arab', 'Asrama Sekolah Harian'),
(16, 'SAM TANJONG KARANG', 'BATU 9 1/2, JALAN BERNAM, TANJONG KARANG, 45500 SELANGOR', 'PPD KUALA SELANGOR', 'Beroperasi', 60332698711, 60332690053, 'Pagi Sahaja', 'Sekolah Bantuan Kerajaan', 'Lelaki dan Perempuan', 'Bahasa Melayu', 'Asrama Sekolah Harian'),
(17, 'SAMT SULTAN SALAHUDDIN ABD AZIZ SHAH', 'BELAKANG MASJID ATTAQWA BT38, SABAK BERNAM, 45200 SELANGOR', 'PPD SABAK BERNAM', 'Beroperasi dengan 1 sekolah cawangan', 60332161270, 60332161648, 'Pagi Sahaja', 'Sekolah Bantuan Kerajaan', 'Lelaki dan Perempuan', 'B. Melayu + B. Arab', 'Asrama Sekolah Harian'),
(18, 'SK POKOK ASAM', 'JALAN SUNGAI TIANG, PENDANG, 06750 KEDAH', 'PPD PENDANG', 'Beroperasi', 6047846209, 6047846209, 'Pagi Sahaja', 'Sekolah Kerajaan', 'Lelaki dan Perempuan', 'Bahasa Melayu', 'Tiada Asrama'),
(19, 'SK LAKSAMANA', 'JALAN TAIPING, KUALA SEPETANG, 34650 PERAK', 'PPD LARUT/MATANG/SELAMA', 'Beroperasi', 6058581084, 6058581084, 'Pagi Sahaja', 'Sekolah Kerajaan', 'Lelaki dan Perempuan', 'Bahasa Melayu', 'Tiada Asrama'),
(20, 'SMK PANGLIMA GARANG ABDUL SAMAD', 'KAMPUNG TANJUNG LALANG, BUDU, BENTA, 27310 PAHANG', 'PPD LIPIS', 'Beroperasi', 6093124437, 6093124437, 'Pagi Sahaja', 'Sekolah Kerajaan', 'Lelaki dan Perempuan', 'Bahasa Melayu', 'Asrama Sekolah Harian');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `id` bigint(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `ic` bigint(100) NOT NULL,
  `alamat` varchar(500) NOT NULL,
  `hp` bigint(50) NOT NULL,
  `jantina` varchar(20) NOT NULL,
  `namaPenjaga` varchar(100) NOT NULL,
  `hpPenjaga` bigint(50) NOT NULL,
  `url` varchar(200) NOT NULL,
  `course` varchar(500) NOT NULL,
  `fakulti` varchar(500) NOT NULL,
  `tmasuk` varchar(200) NOT NULL,
  `tgraduate` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `nama`, `ic`, `alamat`, `hp`, `jantina`, `namaPenjaga`, `hpPenjaga`, `url`, `course`, `fakulti`, `tmasuk`, `tgraduate`) VALUES
(11111111, 'Noor Neelofa Binti Mohd Noor', 850124105251, 'Pasir Mas, Kelantan ', 60131234567, 'Perempuan', 'Mohd Noor bin Ali', 601234456789, 'http://202.171.41.171/images/myUni/11111111.jpg', 'Business Development', 'Fakulti Perniagaan', '25 Julai 2004', '25 Julai 2007'),
(22222222, 'norhafizah musa', 850124105252, 'Kuala Jempol, Negeri Sembilan', 60148762097, 'Perempuan', 'musa bin Abu', 60125678342, 'http://202.171.41.171/images/myUni/22222222.jpg', 'Sastera Bahasa Arab', 'Pengajian Islam', '20 Mei 2001', '30 Mei 2003'),
(33333333, 'Aznil Hj Nawawi', 850124105253, 'Kg Datuk Keramat, KL', 60164253671, 'Lelaki', 'Nawawi bin Aziz', 60124563245, 'http://202.171.41.171/images/myUni/33333333.jpg', 'Ijazah Sarjana Ekonomi', 'Perakaunan', '10 November 2000', '10 Julai 2003'),
(44444444, 'Yunalis Mat Zara''ai', 850124105254, 'Alor Setar, Kedah', 60198765432, 'Perempuan', 'Zara''ai bin Othman', 60175464326, 'http://202.171.41.171/images/myUni/44444444.jpg', 'Sarjana Muda Undang Undang', 'Fakulti Perundangan', '5 April 2003', '7 November 2006');

-- --------------------------------------------------------

--
-- Table structure for table `universiti`
--

CREATE TABLE IF NOT EXISTS `universiti` (
  `id` int(255) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `alamat` varchar(500) NOT NULL,
  `negeri` varchar(15) NOT NULL,
  `telefon` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `website` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `universiti`
--

INSERT INTO `universiti` (`id`, `nama`, `alamat`, `negeri`, `telefon`, `email`, `website`) VALUES
(1, 'Universiti Islam Antarabangsa Malaysia (UIAM)', 'Jalan Gombak 53100 Gombak Selangor.', 'Selangor', '0361964000', 'webmaster@iium.edu.m', 'www.iiu.edu.my'),
(2, 'Universiti Kebangsaan Malaysia (UKM) (Bangi)', '43600 Bangi Selangor', 'Selangor', '0389215039', 'akad@pkrisc.cc.ukm.m', 'www.ukm.my'),
(3, 'Universiti Kebangsaan Malaysia (UKM) (Kuala Lumpur)', 'Fakulti Pergigian, Universiti Kebangsaan Malaysia\r\nJalan Raja Muda Abdul Aziz\r\n50300 Kuala Lumpur\r\nWP Kuala Lumpur', 'Kuala Lumpur', '0392897799', 'dkfdent@dental', 'www.ukm.my'),
(4, 'Universiti Malaya (UM)', 'Jalan Pantai Baharu\r\n50603 Kuala Lumpur\r\nWP Kuala Lumpur', 'Kuala Lumpur', '0379677022', 'icr@um.edu.my', 'www.um.edu.my'),
(5, 'Universiti Malaysia Kelantan (UMK) Kampus Jeli', 'Beg Berkunci No. 100\r\n17600 Jeli\r\nKelantan', 'Kelantan', '099450269', 'phek@groups.edu.my', 'www.umk.edu.my'),
(6, 'Universiti Malaysia Pahang (UMP)', 'Lebuhraya Tun Razak\r\n26300 Gambang, Kuantan\r\nPahang', 'Pahang', '095492501', 'pro@ump.edu.my', 'www.ump.edu.my'),
(7, 'Universiti Malaysia Perlis (UniMAP)', 'Canselori, Tingkat 11, Bangunan KWSP\r\nJalan Bukit Lagi\r\n01000 Kangar\r\nPerlis', 'Perlis', '049798008', 'pro@unimap.edu.my', 'www.unimap.edu.my'),
(8, 'Universiti Malaysia Sabah (UMS)', 'Jalan UMS\r\n88400 Kota Kinabalu\r\nSabah', 'Sabah', '088320000', 'ppa@ums.edu.my', 'www.ums.edu.my'),
(9, 'Universiti Malaysia Sarawak (UNIMAS)', '94300 Kota Samarahan\r\nSarawak', 'Sarawak', '082416550', 'ukp@unimas.my', 'www.unimas.my'),
(10, 'Universiti Malaysia Sarawak (UNIMAS)', 'Fakulti Perubatan dan Sains Kesihatan\r\nLot 77, Seksyen 22, Kuching Town Land District, Jalan Tun Ahmad Zaidi Adruce\r\n93150 Kuching\r\nSarawak', 'Sarawak', '082416 550', 'razlan@fmhs.unim', 'www.unimas.my'),
(11, 'Universiti Malaysia Terengganu (UMT)', 'Mengabang Telipot\r\n21030 Kuala Terengganu\r\nTerengganu', 'Terengganu', '096684219', 'akademik@umt.edu.my', 'www.umt.edu.my'),
(12, 'Universiti Pendidikan Sultan Idris (UPSI)', '35900 Tanjong Malim\r\nPerak', 'Perak', '054506000', 'akademik@upsi.edu.my', 'www.upsi.edu.my'),
(13, 'Universiti Pertahanan Nasional Malaysia (UPNM)', 'Kem Sungai Besi\r\n57000 Kuala Lumpur\r\nWP Kuala Lumpur', 'Kuala Lumpur', '0390513421', 'tnc.heaa@upnm.edu.my', 'www.upnm.edu.my'),
(14, 'Universiti Putra Malaysia (UPM)', '43400 Serdang\r\nSelangor', 'Selangor', '0389466000', 'webmaster@putra', 'www.upm.edu.my'),
(15, 'Universiti Sains Islam Malaysia (USIM)', 'Bandar Baru Nilai\r\n71800 Nilai\r\nNegeri Sembilan', 'Negeri Sembilan', '067988000', 'helpdesk@usim.edu.my', 'www.usim.edu.my'),
(16, 'Universiti Sains Malaysia (USM)', 'Kubang Kerian\r\n16150 Kota Bharu\r\nKelantan', 'Kelantan', '097663500', 'pro@usm.my', 'www.usm.my'),
(17, 'Universiti Sains Malaysia (USM)', '11800 Minden\r\nPulau Pinang', 'Pulau Pinang', '046533140', 'pro@usm.my', 'www.usm.my'),
(18, 'Universiti Sultan Zainal Abidin (UniSZA) ', '21300 Kuala Terengganu\r\nTerengganu', 'Terengganu', '096653300', 'ujk@unisza.edu.my', 'www.unisza.edu.my'),
(19, 'Universiti Teknikal Malaysia Melaka (UTeM)', 'Hang Tuah Jaya\r\n76100 Durian Tunggal\r\nMelaka', 'Melaka', '063316314', 'pjka@utem.edu.my', 'www.utem.edu.my'),
(20, 'Universiti Teknologi Malaysia (UTM)', 'Universiti Teknologi Malaysia (UTM)\r\n81310 Skudai\r\nJohor', 'Johor', '075533333', 'webmaster@utm.my', 'www.utm.my'),
(21, 'Universiti Teknologi MARA (UiTM)', 'Kampus Arau\r\n02600 Arau\r\nPerlis', 'Perlis', '049882000', '', ''),
(22, 'Universiti Utara Malaysia (UUM)', '06010 UUM Sintok\r\nKedah', 'Kedah', '049284000', 'prouum@uum.edu.my', 'www.uum.edu.my');

-- --------------------------------------------------------

--
-- Table structure for table `yuran`
--

CREATE TABLE IF NOT EXISTS `yuran` (
  `id` int(255) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `ic` bigint(20) NOT NULL,
  `tarikh_bayar` varchar(50) NOT NULL,
  `status` varchar(20) NOT NULL,
  `jumlah` int(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `yuran`
--

INSERT INTO `yuran` (`id`, `nama`, `ic`, `tarikh_bayar`, `status`, `jumlah`) VALUES
(1, 'Nor Aizan Awang', 850124115256, '2015-05-10 17:16:18', 'paid', 5),
(3, 'nur rahmah', 850124115257, '', 'unpaid', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `peperiksaan`
--
ALTER TABLE `peperiksaan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `universiti`
--
ALTER TABLE `universiti`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `yuran`
--
ALTER TABLE `yuran`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=60;
--
-- AUTO_INCREMENT for table `peperiksaan`
--
ALTER TABLE `peperiksaan`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `universiti`
--
ALTER TABLE `universiti`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `yuran`
--
ALTER TABLE `yuran`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
