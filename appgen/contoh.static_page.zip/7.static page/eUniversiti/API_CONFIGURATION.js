API MANAGER CONFIGURATION:

i - LIST DROP-DOWN MENU API (Negeri)
Operation Name : any name
API Type : REST
HTTP Method : GET
API Endpoint : http://api.dapat.com/appgen_webservice/negeri_universiti_demo.php
Parameters : 
Return Type : JSON
Resource URI :
Authentication :
(Basic Auth)
Enable : tick

ii - LOGIN API
Operation Name : any name
API Type : REST
HTTP Method : POST
API Endpoint : http://api.dapat.com/appgen_webservice/login_demo.php
Parameters : email&password:passwd
Return Type : JSON
Resource URI :
Authentication :
(Basic Auth)
Enable : tick

iii - DAFTAR API
Operation Name : any name
API Type : REST
HTTP Method : POST
API Endpoint : http://api.dapat.com/appgen_webservice/register_demo.php
Parameters : first_name&last_name&ic&username&email&password&password_confirmation
Return Type : JSON
Resource URI :
Authentication :
(Basic Auth)
Enable : tick

iv - LIST API
Operation Name : any name
API Type : REST
HTTP Method : GET
API Endpoint : http://api.dapat.com/appgen_webservice/dir_universiti_demo.php
Parameters : 
Return Type : JSON
Resource URI :
Authentication :
(Basic Auth)
Enable : tick

v - CARIAN (DROP-DOWN MENU)
Operation Name : any name
API Type : REST
HTTP Method : GET
API Endpoint : http://api.dapat.com/appgen_webservice/search_universiti_demo.php
Parameters : negeri
Return Type : JSON
Resource URI :
Authentication :
(Basic Auth)
Enable : tick

vi - CARIAN API (STUDENT by ic)
Operation Name : any name
API Type : REST
HTTP Method : GET
API Endpoint : http://api.dapat.com/appgen_webservice/student_universiti_demo.php
Parameters : ic
Return Type : JSON
Resource URI :
Authentication :
(Basic Auth)
Enable : tick

vii - CARIAN API (STUDENT by id)
Operation Name : any name
API Type : REST
HTTP Method : GET
API Endpoint : http://api.dapat.com/appgen_webservice/student_universiti_demo2.php
Parameters : id
Return Type : JSON
Resource URI :
Authentication :
(Basic Auth)
Enable : tick




