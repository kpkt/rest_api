 <?php
 
include_once 'config.php';

$db = new mysqli(HOST, USER, PASSWORD, DATABASE);

if (isset($_POST['nama'], $_POST['ic'])) {
    $nama = $_POST['nama'];
	$ic = $_POST['ic'];
 
    if (login($nama, $ic, $db) == 1) {
		 $result = 'IC telah wudah di pangkalan data';

    }else{
		$result = 'Tahniah Pendaftaran berjaya';
	}   
    
} else {
    // The correct POST variables were not sent to this page. 
    $result = 'Please fill in required fields.';
}

header('Content-Type: application/json');
echo json_encode(array('message' => $result));
exit;

function login($nama, $ic, $db) {
    // Using prepared statements means that SQL injection is not possible. 
    if ($stmt = $db->prepare("SELECT id 
        FROM yuran
       WHERE ic = ?
        LIMIT 1")) {
        $stmt->bind_param('s', $ic);  // Bind "$email" to parameter.
        $stmt->execute();    // Execute the prepared query.
        $stmt->store_result();
 
        // get variables from result.
        $stmt->bind_result($user_id, $username, $db_password);
        $stmt->fetch();
        
        if ($stmt->num_rows == 1) {
            return 1;
        } else{
			$sql = "INSERT INTO yuran (nama, ic) VALUES ('$nama', '$ic')";
			if(mysqli_query($db, $sql)){
				return 0;
			}			
		}
        
    }    
}
