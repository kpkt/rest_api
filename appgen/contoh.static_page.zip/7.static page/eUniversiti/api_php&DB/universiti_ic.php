<?php

include_once 'config.php';

$db = new mysqli(HOST, USER, PASSWORD, DATABASE);

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'GET'){
    $ic = $_GET['ic'];
    $results = dir_universiti_listing($ic,$db);
    
    if ($results)
    {
        echo json_encode($results);
	exit;
    }
    else
    {
        echo json_encode(array('error' => 'Tiada rekod.'));
        exit;    
    }
}
else
{
   echo json_encode(array('error' => 'Invalid action.'));
   exit; 
}

function dir_universiti_listing($ic,$db){
    
    $outArr = false;
    
    $stmt1 = $db->prepare("SELECT * from peperiksaan WHERE ic=$ic ORDER BY id ASC");
    $stmt1->execute();
    $stmt1->store_result();
    $stmt1->bind_result($id, $ic, $name, $status);
    while ($stmt1->fetch()) {
        $outArr[] = ['id' => $id, 'ic' => $ic, 'name' => $name, 'status' => $status];
    }
    $stmt1->close();
    
    return $outArr;    
}