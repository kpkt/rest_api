<?php

include_once 'config.php';

$db = new mysqli(HOST, USER, PASSWORD, DATABASE);

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'GET'){
    $ic = $_GET['ic'];
    $results = dir_universiti_listing($ic,$db);
    
    if ($results)
    {
        echo json_encode($results);
	exit;
    }
    else
    {
        echo json_encode(array('error' => 'Tiada rekod.'));
        $result = 'Maaf no kad pengenalan tiada dalam rekod.';    
    }
}
else
{
   echo json_encode(array('error' => 'Invalid action.'));
   exit; 
}

function dir_universiti_listing($ic,$db){
    
    $outArr = false;
    
    $stmt1 = $db->prepare("SELECT * from student WHERE ic=$ic ORDER BY id ASC");
    $stmt1->execute();
    $stmt1->store_result();
    $stmt1->bind_result($id, $name, $ic, $alamat, $hp, $jantina, $namaPenjaga, $hpPenjaga, $url, $course, $fakulti, $tmasuk, $tgraduate);
    while ($stmt1->fetch()) {
        $outArr[] = ['id' => $id, 'name' => $name, 'ic' => $ic, 'alamat' => $alamat, 'hp' => $hp, 'jantina' => $jantina, 'namaPenjaga' => $namaPenjaga, 'hpPenjaga' => $hpPenjaga, 'url' => $url, 'course' => $course, 'fakulti' => $fakulti, 'tmasuk' => $tmasuk, 'tgraduate' => $tgraduate];
    }
    $stmt1->close();
    
    return $outArr;    
}