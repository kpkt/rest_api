<?php

include_once 'config.php';

$db = new mysqli(HOST, USER, PASSWORD, DATABASE);

if ($_SERVER['REQUEST_METHOD'] === 'GET'){
    $ic = $_GET['ic'];
    $amount = $_GET['jumlah'];
    $status = $_GET['status'];
    $tarikh_bayar = $_GET['tarikh_bayar'];
    
	$sql = "UPDATE yuran SET status='$status',jumlah='$amount',tarikh_bayar='$tarikh_bayar' WHERE ic='$ic'";

	if (mysqli_query($db, $sql)) {
		$result = 'Great! You have successful update.';
	} else {
    echo "Error updating record: " . mysqli_error($db);
	}

mysqli_close($db);

	
   
}
else
{
   echo json_encode(array('error' => 'Invalid action.'));
   exit; 
}

header('Content-Type: application/json');
echo json_encode(array('message' => $result));
exit;
