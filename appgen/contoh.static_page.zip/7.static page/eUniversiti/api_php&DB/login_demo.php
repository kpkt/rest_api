 <?php
 
include_once 'config.php';

$db = new mysqli(HOST, USER, PASSWORD, DATABASE);

if (isset($_POST['email'], $_POST['passwd'])) {
    $email = $_POST['email'];
    $password = md5($_POST['passwd']); // The md5 password.
 
    if (login($email, $password, $db) == true) {
        // Login success 
        // $result = 'Great! You have successful login.';
	$result = 1;

    } else {
        // Login failed 
        // $result = 'Login details incorrect!.';
        $result = 0;
    }   
    
} else {
    // The correct POST variables were not sent to this page. 
    $result = 'Please fill in required fields.';
}

header('Content-Type: application/json');
echo json_encode(array('message' => $result));
exit;

function login($email, $password, $db) {
    // Using prepared statements means that SQL injection is not possible. 
    if ($stmt = $db->prepare("SELECT id, username, password 
        FROM members
       WHERE email = ?
        LIMIT 1")) {
        $stmt->bind_param('s', $email);  // Bind "$email" to parameter.
        $stmt->execute();    // Execute the prepared query.
        $stmt->store_result();
 
        // get variables from result.
        $stmt->bind_result($user_id, $username, $db_password);
        $stmt->fetch();
        
        if ($stmt->num_rows == 1) {

          if ($db_password == $password) {
                    // Login successful.
                    return true;
                } else {
                    // Password is not correct;
                    return false;
                }
        
        } else {
            // No user exists.
            return false;
        }
        
    }    
}
