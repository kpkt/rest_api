<?php

include_once 'config.php';

$db = new mysqli(HOST, USER, PASSWORD, DATABASE);

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'GET'){
    
    $results = dir_universiti_listing($db);
    
    if ($results)
    {
        echo json_encode($results);
	exit;
    }
    else
    {
        echo json_encode(array('error' => 'Tiada rekod.'));
        exit;    
    }
}
else
{
   echo json_encode(array('error' => 'Invalid action.'));
   exit; 
}

function dir_universiti_listing($db){
    
    $outArr = false;
    
    $stmt1 = $db->prepare("SELECT * from universiti ORDER BY id ASC");
    $stmt1->execute();
    $stmt1->store_result();
    $stmt1->bind_result($id, $nama, $alamat, $negeri, $telefon, $email, $website);
    while ($stmt1->fetch()) {
        $outArr[] = ['id' => $id, 'nama' => $nama, 'alamat' => $alamat, 'negeri' => $negeri, 'telefon' => $telefon, 'email' => $email, 'website' => $website];
    }
    $stmt1->close();
    
    return $outArr;    
}