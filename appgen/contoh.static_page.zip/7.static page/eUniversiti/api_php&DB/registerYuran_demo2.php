<?php

include_once 'config.php';

$db = new mysqli(HOST, USER, PASSWORD, DATABASE);

header('Content-Type: application/json');

if ($checker)
{
    $inputs = array(
                'nama' => $_POST['nama'],
                'ic' => $_POST['ic'],
                'tarikh_bayar' => $_POST['tarikh_bayar'],
                'status' => $_POST['status'],
                'jumlah' => $_POST['jumlah']
            );
    
    $results = register_user($inputs, $db);
    
    if ($results == 1)
    {
        echo json_encode(array('message' => 'Thank you. You have been registered'));
       // exit;
    }
    else if ($results == 2)
    {
        echo json_encode(array('message' => 'Opps, User with email address already exist.'));
        //exit;
    }
    else
    {
        echo json_encode(array('error' => 'Sorry, there has been a problem inserting your details. Please contact admin'));
        //exit;    
    }
}
else
{
    $result = 'Sila isi semua maklumat yang diperlukan!.';
    echo json_encode(array('error' => 'Please fill in required fields.'));
    exit;
}

function register_user($data, $db){
    
    $stmt1 = $db->prepare("SELECT id from yuran WHERE ic = ?");
    $stmt1->bind_param("s", $data['ic']);
    $stmt1->execute();
    $stmt1->store_result();
    $num_rows = $stmt1->num_rows;
    $stmt1->close();
    
    if ($num_rows > 0){
       return 2; 
    }
    
      $stmt2 = $db->prepare( "INSERT INTO yuran ( nama, ic, tarikh_bayar, status, jumlah ) VALUES ( ?, ?, ?, ?, ? )" );
        $stmt2->bind_param("sssssss", $data['nama'], $data['ic'], $data['tarikh_bayar'], $data['status'], $data['jumlah']);
        $result = $stmt2->execute();
        $stmt2->close();
        $status = ($result)? 1:0;

      return $status;
    
}