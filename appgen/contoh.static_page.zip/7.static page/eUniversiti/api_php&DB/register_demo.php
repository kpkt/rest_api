<?php

include_once 'config.php';

$db = new mysqli(HOST, USER, PASSWORD, DATABASE);

$checker = (!empty($_POST['first_name']) && !empty($_POST['last_name']) && !empty($_POST['ic']) && !empty($_POST['username']) && !empty($_POST['email']) && !empty($_POST['password']) && !empty($_POST['password_confirmation']))? 1:0;

header('Content-Type: application/json');

if ($checker)
{
    $inputs = array(
                'fname' => $_POST['first_name'],
                'lname' => $_POST['last_name'],
                'ic' => $_POST['ic'],
                'username' => $_POST['username'],
                'email' => $_POST['email'],
                'passwd' => md5($_POST['password']),
                'passwd2' => md5($_POST['password_confirmation'])
            );
    
    $results = register_user($inputs, $db);
    
    if ($results == 1)
    {
        echo json_encode(array('message' => 'Thank you. You have been registered'));
       // exit;
    }
    else if ($results == 2)
    {
        echo json_encode(array('message' => 'Opps, User with email address already exist.'));
        //exit;
    }
    else
    {
        echo json_encode(array('error' => 'Sorry, there has been a problem inserting your details. Please contact admin'));
        //exit;    
    }
}
else
{
    $result = 'Sila isi semua maklumat yang diperlukan!.';
    echo json_encode(array('error' => 'Please fill in required fields.'));
    exit;
}

function register_user($data, $db){
    
    $stmt1 = $db->prepare("SELECT id from members WHERE email = ?");
    $stmt1->bind_param("s", $data['email']);
    $stmt1->execute();
    $stmt1->store_result();
    $num_rows = $stmt1->num_rows;
    $stmt1->close();
    
    if ($num_rows > 0){
       return 2; 
    }
    
      $stmt2 = $db->prepare( "INSERT INTO members ( first_name, last_name, nric, username, email, password, password_confirmation ) VALUES ( ?, ?, ?, ?, ?, ?, ? )" );
        $stmt2->bind_param("sssssss", $data['fname'], $data['lname'], $data['ic'], $data['username'], $data['email'], $data['passwd'],$data['passwd2'] );
        $result = $stmt2->execute();
        $stmt2->close();
        $status = ($result)? 1:0;

      return $status;
    
}