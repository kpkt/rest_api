// Config --------------------------------------------------------------

var API_KEY = "601178ef70adbf361d2a69e043c630466dfdd098" //api key dr api manager

var API_LOGIN = 1815    //id call from api manager
var API_REGISTER = 162 //id call from api manager


// State ---------------------------------------------------------------

var RegisterPage = $(".registerPage")
var LoginPage = $(".loginPage")


var ApiCalls = {
    submit: undefined,
}


// Helpers -------------------------------------------------------------

var goBackLoginPage = function ()
{
    LoginPage.show()
    RegisterPage.hide()
    dropBackHandler()
    updateScroller()
}



var goRegisterPage = function ()
{
    LoginPage.hide()
    RegisterPage.show()
    updateScroller()
    addBackHandler(goBackLoginPage)

}

var abortSubmitCall = function ()
{
    if (ApiCalls.submit) {
        ApiCalls.submit.abort()
        ApiCalls.submit = undefined
    }
}

// Page navigation buttons ----

$('.register.link').tap(goRegisterPage)
$('.login.link').tap(goBackLoginPage)


// Login page ----

$('.login.button').tap(function () {
    var loginObj = {}
    var configObj = {}

    loginObj.email = $('[name=email]', LoginPage).val().toString()
    loginObj.password = $('[name=password]', LoginPage).val().toString()

    configObj = {
        bodyParams: loginObj
    }

    abortSubmitCall()
    var ongoingSubmitApiCall = callApi(API_LOGIN, API_KEY, "post", configObj) //method api post or get
    ongoingSubmitApiCall.then(
            function (result) {
                //alert(result.data.message)
                if (result.data != null && !result.data.error) {
                    var userInfo = result.data.message
                    var sessionValidatorFn = function (userInfo, callback) {
                        callback(true)
                    }
                    var logoutFn = function () {
                    }

                    if (!userInfo) {
                        alert("Gagal daftar masuk. Sila cuba lagi.")

                    } else {
                        if (userInfo = 1) {
                            alert("Tahniah.Berjaya daftar masuk")
                            userLoggedIn(userInfo, sessionValidatorFn, logoutFn)
                        } else {

                        }
                    }
                } else {
                    if (result.data.message)
                        alert(result.data.message)
                    else
                        alert("Gagal daftar masuk. Sila cuba lagi.")
                }
            },
            function (result) {
                if (result.status) { // 0 == aborted
                    if (result.data && result.data.message) {
                        alert(result.data.message)
                    } else {
                        alert("Gagal daftar masuk. Sila cuba lagi.")
                    }
                }
            }
    );
})

$('.register.button').tap(function () {
    var signUpObj = {}
    var configObj = {}

    signUpObj.first_name = $('[name=first_name]', RegisterPage).val()
    signUpObj.last_name = $('[name=last_name]', RegisterPage).val()
    signUpObj.ic = $('[name=ic]', RegisterPage).val()
    signUpObj.username = $('[name=username]', RegisterPage).val()
    signUpObj.email = $('[name=email]', RegisterPage).val()
    signUpObj.password = $('[name=password]', RegisterPage).val()
    signUpObj.password_confirmation = $('[name=password_confirmation]', RegisterPage).val()

    configObj = {
        bodyParams: signUpObj
    }

    abortSubmitCall()
    var ongoingSubmitApiCall = callApi(API_REGISTER, API_KEY, "post", configObj) //method api post or get
    ongoingSubmitApiCall.then(
            function (result) {
                if (result.data != null && !result.data.error) {
                    alert(result.data.message)
                    goBackLoginPage()
                } else if (result == 1) {
                    console.log(result)
                } else if (result == 2) {
                    alert(result.data.message)
                } else if (result.data == null) {
                    alert(result.data.message)
                } else {
                    if (result.data.message)
                        alert(result.data.message)
                    else
                        alert("Pendaftaran tidak berjaya. Sila suba lagi.")
                }
            },
            function (result) {
                console.log(result)
                if (result.status) { // 0 == aborted
                    alert("Pendaftaran tidak berjaya: " + result.data.message + ". Sila cuba lagi.")
                }
            }
    )
})